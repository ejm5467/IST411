/**
 * @authors Team 3
 * Kara MacClean, Emily Malnor, Karin Martin
 * IST411 SP18
 * Lesson 4: Group Work - Create a server and use GET & POST
 */


//Modify the server code to handle the case that the HTTP method equals “POST”
//HTTP requests using the POST method should update a file on the server containing all of the diary posts.
//HTTP requests using the GET method should display the entire contents of the diary.
//Modify the sample HTTP client to POST a string of text to the diary and GET (and display) the current contents of the diary.


//update reference!
//Original code borrowed from Liang, Y. D. (2014). Reading data from the web. In Intro to 
//java programming, comprehensive version (10th ed., p. 122). Prentice Hall.

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class WebServer {

    public WebServer() {
        System.out.println("Webserver Started");
        try (ServerSocket serverSocket = new ServerSocket(80)) {
            while (true) {
                System.out.println("Waiting for client request");
                Socket remote = serverSocket.accept();
                System.out.println("Connection made");
                new Thread(new ClientHandler(remote)).start();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public static void main(String args[]) {
        new WebServer();
    }
}