/**
 * @authors Team 3
 * Emily Malnor, Karin Martin
 * IST411 SP18
 * Lesson 4: Group Work - Create a server and use GET & POST
 */

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.StringTokenizer;
import java.util.Scanner;

public class ClientHandler implements Runnable {

    private final Socket sockt;
    private FileWriter fw;
    private Scanner scn;

    public ClientHandler(Socket socket) {
        this.sockt = socket;
    }

    @Override
    public void run() {
        System.out.println("\nClientHandler Started for " + 
            this.sockt);
        handleRequest(this.sockt);
        System.out.println("ClientHandler Terminated for " 
            + this.sockt + "\n");
    }

    public void sendResponse(Socket socket, 
        int statusCode, String responseString) {
            String statusLine;
            String serverHeader = "Server: WebServer\r\n";
            String contentTypeHeader = "Content-Type: text/html\r\n";

            try (DataOutputStream out = new DataOutputStream(socket.getOutputStream());) {

                if (statusCode == 200) {
                    statusLine = "HTTP/1.0 200 OK" + "\r\n";
                    String contentLengthHeader = "Content-Length: " 
                        + responseString.length() + "\r\n";

                    out.writeBytes(statusLine);
                    out.writeBytes(serverHeader);
                    out.writeBytes(contentTypeHeader);
                    out.writeBytes(contentLengthHeader);
                    out.writeBytes("\r\n");
                    out.writeBytes(responseString);
                } else if (statusCode == 405) {
                    statusLine = "HTTP/1.0 405 Method Not Allowed" + "\r\n";
                    out.writeBytes(statusLine);
                    out.writeBytes("\r\n");
                } else {
                    statusLine = "HTTP/1.0 404 Not Found" + "\r\n";
                    out.writeBytes(statusLine);
                    out.writeBytes("\r\n");
                }            
                         
                out.close();
            } catch (IOException ex) {
                // Handle exception
        }
    }    
    
    public void handleRequest(Socket socket) {
        try (BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));) {
            String headerLine = in.readLine();
            StringTokenizer tokenizer = 
                new StringTokenizer(headerLine);
            String httpMethod = tokenizer.nextToken();
            
            if (httpMethod.equals("GET")) {
                    System.out.println("Get method processed");
                    StringBuilder responseBuffer = new StringBuilder();
                    
                    File diary = new File("diary.txt");
                    Scanner scn = new Scanner(diary);
                    while (scn.hasNextLine() == (true)){
                        System.out.println(scn.nextLine());
                    }                    
                    responseBuffer
                        .append("<html><h1>WebServer Home Page.... </h1><br>")
                        .append("<b>Welcome to my web server!</b><BR>")
                        .append("</html>");
                    sendResponse(socket, 200, responseBuffer.toString());
            } else if (httpMethod.equals("POST")) {
                    System.out.println("Post method processed"); 
                    
                    fw = new FileWriter("diary.txt", true);
                    fw.write("New Entry: ");
                    
                    String diaryentry;
                    System.out.print("Please enter diary entry: ");
                    scn = new Scanner(System.in);
                    diaryentry = scn.nextLine();
                    fw.write(diaryentry + "\r\n");
                    fw.close();
                  
                    
                    StringBuilder responseBuffer = new StringBuilder();
                    responseBuffer
                        .append("<html><h1>WebServer Home Page.... </h1><br>")
                        .append("<b>Welcome to my web server!</b><BR>")
                        .append("</html>");
                    sendResponse(socket, 200, responseBuffer.toString());                  
            
            } else {
                System.out.println("The HTTP method is not recognized");
                sendResponse(socket, 405, "Method Not Allowed");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
}
