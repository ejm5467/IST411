
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.io.FileReader;

/**
 * @authors Team 3
*  Emily Malnor, Karin Martin
 * IST411 SP18
 * Lesson 4: Group Work - Create a server and use GET & POST
 */

public class HTTPClient {
    
    public HTTPClient() {
        System.out.println("HTTP Client Started");
        try {
            InetAddress serverInetAddress = 
               InetAddress.getByName("127.0.0.1");
            Socket connection = new Socket(serverInetAddress, 80);

            try (OutputStream out = connection.getOutputStream();
                 BufferedReader in = 
                     new BufferedReader(new 
                         InputStreamReader(
                             connection.getInputStream()))) {
                sendGet(out);
                //sendPost(out);
                System.out.println(getResponse(in));
            }
            
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        
        try {
            InetAddress serverInetAddress = 
               InetAddress.getByName("127.0.0.1");
            Socket connection = new Socket(serverInetAddress, 80);

            try (OutputStream out = connection.getOutputStream();
                 BufferedReader in = 
                     new BufferedReader(new 
                         InputStreamReader(
                             connection.getInputStream()))) {
                //sendGet(out);
                sendPost(out);
                System.out.println(getResponse(in));
            }
            
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        
        try {
            InetAddress serverInetAddress = 
               InetAddress.getByName("127.0.0.1");
            Socket connection = new Socket(serverInetAddress, 80);

            try (OutputStream out = connection.getOutputStream();
                 BufferedReader in = 
                     new BufferedReader(new 
                         InputStreamReader(
                             connection.getInputStream()))) {
//                getDiary(out);
            sendGet(out);
                System.out.println(getResponse(in));
            }
            
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    private void sendGet(OutputStream out) {
        try {
            out.write("GET /default\r\n".getBytes());
            out.write("User-Agent: Mozilla/5.0\r\n".getBytes());
            
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    private void sendPost(OutputStream out) {
        try {
            out.write("POST /default\r\n".getBytes());
            out.write("User-Agent: Mozilla/5.0\r\n".getBytes());
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    private String getResponse(BufferedReader in) {
        try {
            String inputLine;
            StringBuilder response = new StringBuilder();
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine).append("\n");
            }
            return response.toString();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return "";
    }

    public static void main(String[] args) {
        new HTTPClient();
    }

    private void getDiary(OutputStream out) {
        try {
            out.write("GET /diary.txt\r\n".getBytes());
            out.write("User-Agent: Mozilla/5.0\r\n".getBytes());
            
//            out.write("FileReader fr = new FileReader('diary.txt')\r\n".getBytes());
//            out.write("char [] a = new char[50]\r\n".getBytes());
//            out.write("fr.read(a)\r\n".getBytes());
//            out.write("for(char c:a) System.out.print(c)\r\n".getBytes());
//            out.write("fr.close\r\n".getBytes());
            
            
            
            
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}   
    

